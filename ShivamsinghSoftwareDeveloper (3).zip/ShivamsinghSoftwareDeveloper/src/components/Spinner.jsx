import React from 'react'

function Spinner() {
  return (
    <div>
        <div className='spinner mx-auto'></div>
      
    </div>
  )
}

export default Spinner
